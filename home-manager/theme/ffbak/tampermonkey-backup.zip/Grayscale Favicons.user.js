// ==UserScript==
// @name         Grayscale Favicons
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Convert all favicons to grayscale on any website
// @author       ChatGPT
// @match        *://*/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    function toGrayscale(imgUrl, callback) {
        let img = new Image();
        img.crossOrigin = "anonymous";
        img.src = imgUrl;
        img.onload = function() {
            let canvas = document.createElement("canvas");
            let ctx = canvas.getContext("2d");

            canvas.width = img.width;
            canvas.height = img.height;
            ctx.drawImage(img, 0, 0);

            let imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
            let data = imageData.data;

            for (let i = 0; i < data.length; i += 4) {
                let avg = (data[i] + data[i + 1] + data[i + 2]) / 3;
                data[i] = data[i + 1] = data[i + 2] = avg;
            }

            ctx.putImageData(imageData, 0, 0);
            callback(canvas.toDataURL("image/png"));
        };
    }

    function replaceFavicon() {
        let links = document.querySelectorAll('link[rel*="icon"]');
        links.forEach(link => {
            let originalHref = link.href;
            toGrayscale(originalHref, function(grayscaleUrl) {
                link.href = grayscaleUrl;
            });
        });
    }

    replaceFavicon();
})();
