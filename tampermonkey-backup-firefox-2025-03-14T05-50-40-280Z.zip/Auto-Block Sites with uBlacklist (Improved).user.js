// ==UserScript==
// @name         Auto-Block Sites with uBlacklist (Improved)
// @namespace    http://tampermonkey.net/
// @version      1.2
// @description  Automatically clicks "Block this site" buttons from uBlacklist after searching.
// @author       YourName
// @match        *://www.google.com/search*
// @match        *://www.bing.com/search*
// @match        *://search.yahoo.com/search*
// @match        *://duckduckgo.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    function clickBlockButtons() {
        let buttons = document.querySelectorAll('.ub-button');
        if (buttons.length > 0) {
            console.log(`[uBlacklist Auto-Block] Found ${buttons.length} block buttons. Clicking them...`);
            buttons.forEach(button => {
                // Simulate a user click event
                let event = new MouseEvent('click', { bubbles: true, cancelable: true, view: window });
                button.dispatchEvent(event);
            });
        } else {
            console.log("[uBlacklist Auto-Block] No block buttons found.");
        }
    }

    // Run once on initial page load
    setTimeout(clickBlockButtons, 2000);

    // Watch for dynamically loaded search results
    const observer = new MutationObserver(() => {
        console.log("[uBlacklist Auto-Block] Search results updated, checking for block buttons...");
        clickBlockButtons();
    });

    // Observe changes in the main search results area
    let resultsContainer = document.querySelector('#search') || document.body; // Google: #search, fallback: body
    observer.observe(resultsContainer, { childList: true, subtree: true });

})();
