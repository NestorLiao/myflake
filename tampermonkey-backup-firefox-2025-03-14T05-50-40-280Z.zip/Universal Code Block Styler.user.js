// ==UserScript==
// @name         Universal Code Block Styler
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Change code block background to white and text to black across all sites
// @author       You
// @match        *://*/*
// @grant        GM_addStyle
// ==/UserScript==

(function() {
    'use strict';

    // Add custom CSS for specific sites (e.g., Deepseek)
    GM_addStyle(`
        /* Deepseek-specific styles */
        .md-code-block > pre,
        .ds-markdown pre,
        [s__="12"],
        .md-code-block {
            color: black !important;
            background-color: white !important;
        }
    `);

    // Function to apply styles to code blocks
    function styleCodeBlocks() {
        // Select all elements with relevant classes or attributes
        const codeBlocks = document.querySelectorAll(`
            .highlight,
            .code-block,
            .md-code-block > pre,
            .ds-markdown pre,
            [s__="12"],
            .md-code-block
        `);

        codeBlocks.forEach(block => {
            // Apply white background and black text color
            block.style.backgroundColor = '#ffffff';
            block.style.color = '#000000';

            // Style child elements (like <pre>, <code>, or <span>)
            const children = block.querySelectorAll('pre, code, span');
            children.forEach(child => {
                child.style.backgroundColor = '#ffffff';
                child.style.color = '#000000';
            });
        });
    }

    // Run the function immediately
    styleCodeBlocks();

    // Use a MutationObserver to handle dynamically loaded content
    const observer = new MutationObserver(styleCodeBlocks);
    observer.observe(document.body, { childList: true, subtree: true });
})();