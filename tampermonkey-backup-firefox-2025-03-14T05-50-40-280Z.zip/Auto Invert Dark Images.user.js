// ==UserScript==
// @name         Auto Invert Dark Images
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Automatically invert dark images based on average brightness
// @match        *://*/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Function to analyze an image and apply inversion if it's predominantly dark
    function analyzeAndInvertImage(img) {
        // Create an off-screen canvas
        var canvas = document.createElement('canvas');
        var ctx = canvas.getContext('2d');

        // Use the image's natural dimensions
        canvas.width = img.naturalWidth;
        canvas.height = img.naturalHeight;

        // Attempt to draw the image onto the canvas (may fail due to CORS)
        try {
            ctx.drawImage(img, 0, 0);
        } catch (e) {
            console.warn("Unable to access image data (possible CORS issue):", img.src);
            return;
        }

        // Retrieve the image data from the canvas
        var imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        var data = imageData.data;

        // Compute the average brightness using the Rec. 709 formula
        var totalBrightness = 0;
        var pixelCount = 0;
        for (var i = 0; i < data.length; i += 4) {
            var r = data[i],
                g = data[i + 1],
                b = data[i + 2];
            // Luminance formula: weighted sum of RGB components
            var brightness = 0.2126 * r + 0.7152 * g + 0.0722 * b;
            totalBrightness += brightness;
            pixelCount++;
        }
        var avgBrightness = totalBrightness / pixelCount;

        // Define a threshold (0-255 scale); here 128 is used as a midpoint
        if (avgBrightness < 128) {
            // Invert the image colors if it's predominantly dark
            img.style.filter = "invert(1)";
        }
    }

    // Process all images on the page
    function processImages() {
        var images = document.querySelectorAll('img');
        images.forEach(function(img) {
            if (img.complete) {
                analyzeAndInvertImage(img);
            } else {
                // Ensure the image is processed once loaded
                img.addEventListener('load', function() {
                    analyzeAndInvertImage(img);
                });
            }
        });
    }

    // Run processing once the document is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', processImages);
    } else {
        processImages();
    }
})();
