// ==UserScript==
// @name         LFS Doc Wide Text
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Make LFS documentation text wider for a vertical screen
// @author       You
// @match        https://www.linuxfromscratch.org/lfs/*
// @grant        GM_addStyle
// ==/UserScript==

(function() {
    'use strict';

    GM_addStyle(`
        div.main {
            left: 2em !important; /* Adjust left margin */
            padding-right: 2em !important; /* Reduce right padding */
            max-width: 95% !important; /* Increase max width */
        }
    `);
})();
